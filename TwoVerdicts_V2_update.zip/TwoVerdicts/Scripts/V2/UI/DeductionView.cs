using System;
using TMPro;
using TwoVerdicts.V2.Core;
using TwoVerdicts.V2.Data;
using UnityEngine;
using UnityEngine.UI;

namespace TwoVerdicts.V2.UI
{
    /// <summary>
    /// 추리 보드. 카드 두 장을 골라 "연결한다". 맞는 조합이면 V2Game 이 결론 선택지를 띄움.
    /// </summary>
    public class DeductionView : View
    {
        private Button slotA;
        private Button slotB;
        private Button connectButton;
        private TextMeshProUGUI noteText;
        private string cardA;
        private string cardB;

        public Action<int> OnSlotClicked { get; set; }
        public Action<string, string> OnConnect { get; set; }
        public Action OnTree { get; set; }

        public static DeductionView Create(Transform parent) => CreateView<DeductionView>(parent, "Deduction");

        protected override void Build()
        {
            Ui.Image(Ui.Stretch("Dim", transform), null, new Color(0f, 0f, 0f, 0.85f), true);
            Ui.Box(transform, "Board", 640f, 340f, 1000f, 480f, 0.98f);
            Ui.Label(transform, "Title", "추리 보드", 640f, 140f, 900f, 44f, 30f, Ui.Paper, TextAlignmentOptions.Center);
            Ui.Label(transform, "Sub", "단서 두 장을 이어서 결론을 내린다. 막히면 단서 트리를 보자.",
                640f, 186f, 900f, 30f, 18f, Ui.Gray, TextAlignmentOptions.Center);
            slotA = Ui.Button(transform, "단서 A 고르기", 400f, 300f, 360f, 90f, () => OnSlotClicked?.Invoke(0), 20f);
            slotB = Ui.Button(transform, "단서 B 고르기", 880f, 300f, 360f, 90f, () => OnSlotClicked?.Invoke(1), 20f);
            Ui.Label(transform, "Plus", "+", 640f, 300f, 60f, 60f, 40f, Ui.Red, TextAlignmentOptions.Center);
            noteText = Ui.Label(transform, "Note", "", 640f, 400f, 900f, 40f, 18f, Ui.Gray, TextAlignmentOptions.Center);
            connectButton = Ui.Button(transform, "연결한다", 540f, 500f, 220f, 60f, Connect, 22f);
            Ui.Button(transform, "닫기", 760f, 500f, 160f, 60f, Close);
            Ui.Button(transform, "단서 트리 보기 (T)", 640f, 560f, 300f, 44f, () => OnTree?.Invoke(), 17f);
        }

        public void Show()
        {
            cardA = null;
            cardB = null;
            Ui.SetLabel(slotA, "단서 A 고르기");
            Ui.SetLabel(slotB, "단서 B 고르기");
            noteText.text = "";
            connectButton.interactable = false;
            OpenView();
        }

        public void SetSlot(int index, string cardId)
        {
            Card card = StoryDb.GetCard(cardId);
            if (card == null) return;
            if (index == 0) cardA = cardId;
            else cardB = cardId;
            Ui.SetLabel(index == 0 ? slotA : slotB, card.Name);
            connectButton.interactable = cardA != null && cardB != null && cardA != cardB;
        }

        public void SetNote(string text) => noteText.text = text;

        private void Connect()
        {
            if (cardA == null || cardB == null) return;
            OnConnect?.Invoke(cardA, cardB);
        }

        private void Update()
        {
            if (KeyReady && (InputLock.Pressed(UnityEngine.InputSystem.Key.Escape) || InputLock.Pressed(UnityEngine.InputSystem.Key.Tab))) Close();
        }

        public void Close() => CloseView();
    }
}
