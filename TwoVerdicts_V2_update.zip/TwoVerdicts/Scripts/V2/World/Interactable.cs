using UnityEngine;

namespace TwoVerdicts.V2.World
{
    public enum InteractKind { Spot, Npc, Door }

    /// <summary>
    /// 방 안에서 E 로 쓸 수 있는 것. 돋보기(Shift)를 누르면 아직 안 본 단서가 반짝인다.
    /// </summary>
    public class Interactable : MonoBehaviour
    {
        public const float UseRange = 1.3f;
        public const float GlintRange = 4.5f;

        public InteractKind Kind { get; private set; }
        public string Key { get; private set; }
        public string Label { get; private set; }
        public float X => transform.position.x;
        public bool Spent { get; set; }

        private SpriteRenderer glint;

        public void Setup(InteractKind kind, string key, string label, SpriteRenderer glintRenderer)
        {
            Kind = kind;
            Key = key;
            Label = label;
            glint = glintRenderer;
            if (glint != null) glint.enabled = false;
        }

        public void ShowGlint(bool show)
        {
            if (glint == null) return;
            glint.enabled = show && !Spent;
            if (glint.enabled)
            {
                float a = 0.5f + 0.5f * Mathf.Sin(Time.time * 8f);
                glint.color = new Color(1f, 1f, 1f, a);
            }
        }
    }
}
