using UnityEditor;
using UnityEngine;

namespace TwoVerdicts.EditorTools
{
    /// <summary>
    /// Assets/TwoVerdicts/Art 아래 PNG 를 픽셀아트용 스프라이트로 임포트.
    /// 새로 들어오는 파일은 자동, 이미 들어온 파일은 ApplyAll 로 다시 적용.
    /// </summary>
    public class ArtImportSettings : AssetPostprocessor
    {
        public const string ArtFolder = "Assets/TwoVerdicts/Art";

        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith(ArtFolder)) return;
            Configure((TextureImporter)assetImporter, assetPath);
        }

        public static void Configure(TextureImporter importer, string path)
        {
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.filterMode = FilterMode.Point;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.mipmapEnabled = false;
            importer.alphaIsTransparency = true;
            importer.spriteBorder = BorderFor(path);
        }

        private static Vector4 BorderFor(string path)
        {
            if (path.Contains("ui_dialogue_frame")) return new Vector4(12, 12, 12, 12);
            if (path.Contains("ui_button")) return new Vector4(8, 8, 8, 8);
            return Vector4.zero;
        }

        public static void ApplyAll()
        {
            string[] guids = AssetDatabase.FindAssets("t:Texture2D", new[] { ArtFolder });
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (!(AssetImporter.GetAtPath(path) is TextureImporter importer)) continue;
                Configure(importer, path);
                importer.SaveAndReimport();
            }
            SetupLog.Info($"아트 임포트 설정 적용: {guids.Length}개");
        }
    }
}
